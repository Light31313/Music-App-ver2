package gam.trainingcourse.gst_lesson7_8_ex1_giangnh44.view.adapter


interface ISongAdapter {
    fun onClickItem(position: Int)

}