package gam.trainingcourse.gst_lesson7_8_ex1_giangnh44.utils

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import java.io.IOException

class MediaPlayerUtils {
    companion object {
        const val TAG = "MediaPlayerUtils"
    }

    private var mediaPlayer = MediaPlayer()

    init {
        mediaPlayer.setOnPreparedListener {
            start()
        }
    }

    val isLooping
        get() = mediaPlayer.isLooping

    val isPlaying
        get() = mediaPlayer.isPlaying

    fun setDataSource(context: Context, resId: Int) {
        mediaPlayer = MediaPlayer.create(context, resId)

    }

    fun setDataSource(context: Context, uri: Uri) {
        try {
            mediaPlayer.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            mediaPlayer.setDataSource(context, uri)
        } catch (e: IOException) {
            Log.d(TAG, "setDataSource: ${e.message}")
        }
    }

    fun setDataSource(url: String) {
        try {
            mediaPlayer.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            mediaPlayer.setDataSource(url)
            mediaPlayer.prepareAsync()
        } catch (e: IOException) {
            Log.d(TAG, "setDataSource: ${e.message}")

        }
    }


    fun start() {
        mediaPlayer.start()
    }

    fun pause() {
        mediaPlayer.pause()
    }

    fun stop() {
        mediaPlayer.stop()
    }

    fun reset() {
        mediaPlayer.reset()
    }

    fun getCurrentPosition(): Int =
        mediaPlayer.currentPosition / 1000


    fun getDuration(): Int =
        mediaPlayer.duration / 1000


    fun seekTo(seconds: Int) {
        if (seconds <= getDuration())
            mediaPlayer.seekTo(seconds * 1000)
    }

    fun rewind(seconds: Int) {
        seekTo((getCurrentPosition() - seconds).coerceAtLeast(0))
    }

    fun fastForward(seconds: Int) {
        seekTo((getCurrentPosition() + seconds).coerceAtMost(getDuration()))
    }

    fun setLoop(isLoop: Boolean) {
        mediaPlayer.isLooping = isLoop
    }

    fun release() {
        mediaPlayer.release()
    }
}
