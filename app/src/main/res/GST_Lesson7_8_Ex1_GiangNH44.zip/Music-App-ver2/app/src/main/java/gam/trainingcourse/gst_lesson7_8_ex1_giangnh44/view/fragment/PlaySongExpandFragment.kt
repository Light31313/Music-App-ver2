package gam.trainingcourse.gst_lesson7_8_ex1_giangnh44.view.fragment

import android.animation.Animator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.Color
import android.os.Bundle
import android.os.IBinder
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.view.animation.DecelerateInterpolator
import androidx.fragment.app.activityViewModels
import dagger.hilt.android.AndroidEntryPoint
import gam.trainingcourse.gst_lesson7_8_ex1_giangnh44.R
import gam.trainingcourse.gst_lesson7_8_ex1_giangnh44.base.BaseFragment
import gam.trainingcourse.gst_lesson7_8_ex1_giangnh44.databinding.FragmentPlaySongExpandBinding
import gam.trainingcourse.gst_lesson7_8_ex1_giangnh44.service.PlayingService
import gam.trainingcourse.gst_lesson7_8_ex1_giangnh44.utils.MusicManager
import gam.trainingcourse.gst_lesson7_8_ex1_giangnh44.viewmodel.MusicViewModel

@AndroidEntryPoint
class PlaySongExpandFragment : BaseFragment<FragmentPlaySongExpandBinding>() {
    companion object {
        const val TAG = "PlaySongExpandFragment"
    }

    private val viewModel: MusicViewModel by activityViewModels()

    private lateinit var playingService: PlayingService
    private var isBound: Boolean = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as PlayingService.PlayingBinder
            playingService = binder.getPlayingService()
            isBound = true
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            isBound = false
        }
    }

    private var rotateAnimator: Animator? = null

    override fun createBinding(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): FragmentPlaySongExpandBinding =
        FragmentPlaySongExpandBinding.inflate(inflater, container, false)


    override fun observerLiveData() = with(binding) {
        MusicManager.playingSong.observe(viewLifecycleOwner) { playingSong ->
            song = playingSong

        }

        MusicManager.isPlaying.observe(viewLifecycleOwner) { isPlaying ->
            if (isPlaying) {
                rotateAnimator?.start()
                btnPlay.setImageResource(R.drawable.ic_baseline_pause_circle_outline_24)
            } else {
                rotateAnimator?.cancel()
                btnPlay.setImageResource(R.drawable.ic_baseline_play_circle_outline_24)
            }

        }

        viewModel.isExpand.observe(viewLifecycleOwner) { isExpand ->
            if (isExpand && isHidden) {
                val translateUpAnimation =
                    AnimationUtils.loadAnimation(requireContext(), R.anim.translation_up_animation)
                        .apply {
                            duration = 1500
                            interpolator = DecelerateInterpolator()
                        }
                clPlayMusic.startAnimation(translateUpAnimation)
                parentFragmentManager.beginTransaction().show(this@PlaySongExpandFragment).commit()
            } else if (!isExpand && !isHidden) {
                val translateDownAnimation =
                    AnimationUtils.loadAnimation(
                        requireContext(),
                        R.anim.translation_down_animation
                    )
                        .apply {
                            duration = 1500
                            interpolator = DecelerateInterpolator()
                        }
                clPlayMusic.startAnimation(translateDownAnimation)
                parentFragmentManager.beginTransaction().hide(this@PlaySongExpandFragment).commit()
            }

        }
    }

    override fun initView() {
        parentFragmentManager.beginTransaction().hide(this).commit()
        initAnimation()
    }

    private fun initAnimation() = with(binding) {
        rotateAnimator = ObjectAnimator.ofFloat(imgPlaySong, "rotation", 360F).apply {
            duration = 10000L
            repeatCount = ValueAnimator.INFINITE
            interpolator = null
        }
    }

    override fun initEvent() = with(binding) {
        btnCollapse.setOnClickListener {
            viewModel.setExpand(false)
        }

        btnNext.setOnClickListener {
            if (isBound)
                playingService.nextSong()
        }

        btnPrev.setOnClickListener {
            if (isBound)
                playingService.prevSong()
        }

        btnLoop.setOnClickListener { button ->
            if (MusicManager.isLooping) {
                button.setBackgroundColor(Color.TRANSPARENT)
                MusicManager.setLoop(false)
            } else {
                button.setBackgroundColor(Color.BLUE)
                MusicManager.setLoop(true)
            }
        }

        btnShuffle.setOnClickListener { }

        btnPlay.setOnClickListener {
            if (isBound)
                playingService.playSong()
        }
    }

    override fun onStart() {
        super.onStart()
        Intent(requireContext(), PlayingService::class.java).also { intent ->
            requireContext().bindService(intent, connection, Context.BIND_AUTO_CREATE)
        }
    }

    override fun onStop() {
        super.onStop()
        requireContext().unbindService(connection)
        isBound = false
    }
}