package gam.trainingcourse.gst_lesson7_8_ex1_giangnh44.utils

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import gam.trainingcourse.gst_lesson7_8_ex1_giangnh44.model.Song

object MusicManager {
    private val mSongs = MutableLiveData<List<Song>>()
    val songs: LiveData<List<Song>>
        get() = mSongs

    fun setSongs(songs: List<Song>) {
        mSongs.value = songs
    }

    private val mPlayingSong = MutableLiveData<Song>()
    val playingSong: LiveData<Song>
        get() = mPlayingSong

    fun setPlayingSong(song: Song) {
        mPlayingSong.value = song
    }

    var currentPlayingPosition = 0

    private val mediaPlayerUtils = MediaPlayerUtils()

    private val mIsPlaying = MutableLiveData(true)
    val isPlaying: LiveData<Boolean>
        get() = mIsPlaying

    val isLooping
        get() = mediaPlayerUtils.isLooping

    fun startSong() {
        mediaPlayerUtils.reset()
        mPlayingSong.value?.let {
            mediaPlayerUtils.setDataSource(it.songUrl)
            mIsPlaying.value = true
        }

    }

    fun playMusic() {
        mIsPlaying.value = if (mediaPlayerUtils.isPlaying) {
            mediaPlayerUtils.pause()
            false
        } else {
            mediaPlayerUtils.start()
            true
        }

    }

    fun getCurrentPosition(): Int = mediaPlayerUtils.getCurrentPosition()

    fun getDuration(): Int = mediaPlayerUtils.getDuration()

    fun nextSong() {
        mediaPlayerUtils.reset()
        currentPlayingPosition += 1
        songs.value?.let {
            if (currentPlayingPosition > it.size - 1)
                currentPlayingPosition = 0
            mPlayingSong.value = it[currentPlayingPosition]
            startSong()
        }
    }

    fun previousSong() {
        mediaPlayerUtils.reset()
        currentPlayingPosition -= 1
        songs.value?.let {
            if (currentPlayingPosition < 0)
                currentPlayingPosition = it.size - 1
            mPlayingSong.value = it[currentPlayingPosition]
            startSong()
        }
    }

    fun setLoop(isLoop: Boolean) {
        mediaPlayerUtils.setLoop(isLoop)
    }
}