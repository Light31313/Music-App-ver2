package gam.trainingcourse.gst_lesson7_8_ex1_giangnh44.utils

import android.R.attr
import android.graphics.drawable.Drawable
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import gam.trainingcourse.gst_lesson7_8_ex1_giangnh44.R


@BindingAdapter("imageUrl")
fun ImageView.loadImageByUrl(imageUrl: String?) {
    imageUrl?.let {
        Glide.with(this).load(it).placeholder(R.drawable.ic_baseline_eco_24).into(this)
    }
}

@BindingAdapter("themeImageUrl")
fun View.loadMainThemeColorFromImage(imageUrl: String?){
    imageUrl?.let {
        Glide.with(this).load(it).listener(object : RequestListener<Drawable>{
            override fun onLoadFailed(
                e: GlideException?,
                model: Any?,
                target: Target<Drawable>?,
                isFirstResource: Boolean
            ): Boolean {
                Toast.makeText(this@loadMainThemeColorFromImage.context, e?.message, Toast.LENGTH_LONG).show()
                return false
            }

            override fun onResourceReady(
                resource: Drawable?,
                model: Any?,
                target: Target<Drawable>?,
                dataSource: DataSource?,
                isFirstResource: Boolean
            ): Boolean {
                val p: Palette = Palette.from(attr.resource).generate()
                // Use generated instance
                holder.mColorPalette = p.getMutedColor(
                    ContextCompat.getColor(
                        mParentActivity,
                        R.color.movieDetailTitleBg
                    )
                )
                return true
            }

        })
    }
}